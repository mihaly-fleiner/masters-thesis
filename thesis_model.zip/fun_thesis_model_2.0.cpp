//#define EIGENLIB			// uncomment to use Eigen linear algebra library

#include "fun_head_fast.h"
#include <cmath>
#include <iostream>

// do not add Equations in this area

MODELBEGIN

// insert your equations here, ONLY between the MODELBEGIN and MODELEND words

//////////////////
///Network equation
/////////////////

EQUATION("Network_init")
//v[0]=V("avg_out_degree");
//v[1]=V("exp_scale_factor");//usually between 2 and 3??
//INIT_NET("People","SCALE-FREE",0,v[0],v[1]);
//INIT_NET("People", "RANDOM-UNDIR", 0, 2*1000*10);

//LOAD_NET("People", "xbs_p1_rich300_out_degree_20");
//LOAD_NET("People", "xbs_p0.2_rich100_out_degree_10\\xbs_p0.2_rich100_out_degree_10");
LOAD_NET("People", "homogen\\homogen_out_degree_10");



PARAMETER;
RESULT(1)

//////////////////
///People equations
/////////////////


EQUATION("Systematic_shock")
v[0] = 0; //no shock
v[1] = 0.05; //probability of a negative systematic shock
if(RND<v[1])
	{
	v[0] = norm(5,2); //mean and variance/st.dev? of the shock (%)
	}
//v[0] = 0;  //excluding systematic shocks for now
RESULT(v[0])

EQUATION("Theta")
v[0] = V("Systematic_shock")/100; //systematic shock default value
//v[0] = 0;
v[1] = V("Theta_mean"); //The default theta value
if(V("Systematic_shock")<0)
	{
	v[0] = 0; //we only analize negative shocks
	}

v[2] = norm(0,0.1); //mean and variance of idiosyncratic shock
//v[2] = 0;  //excluding idionsyncratic
v[3] = v[1] + v[0] + v[2]; //the individual theta
v[3] = v[0] + v[1];
v[3] = v[1];
RESULT(v[3])

EQUATION("Early_1")
v[0] = V("Theta");
v[1] = 0; //default: late consumer
if(RND<v[0])
	{
	v[1] = 1; //with theta probability, the agent will become early consumer
	}
RESULT(v[1])


EQUATION( "panic_prop" )

	v[0] = VL("panic_prop", 1);
	v[1] = 0; //propensity update (reward)
	
	//v[1] = (VL("Sum_early", 1)-VL("Sum_early",2))/100 * 1/V("roth_alpha") * 1/2;   //effect of non-neighbouring early	
	
	CYCLE_LINK(curl)
	{
		
		cur2 = LINKTO(curl); 
		
		if (VLS(cur2, "Early_2", 1) == 1){
			v[1] = v[1] + 1/V("roth_alpha") * 1; 			//effect of neighbour panicing
		}
	}
	
	if (VL("Early_2", 1) == 1 && VL("bankrun_flag", 1) == 0)
	{
		v[1] = v[1] - 1/V("roth_alpha") * 100;		//effect of false panicing - kell hogy ilyen nagy. le lehetne irni a kulonbseget a kul ertekek kozott (lsd kek fuzet)
	}
	
	v[2] = (1-V("roth_alpha"))*v[0] + V("roth_alpha")*v[1];
	
	if (VL("bankrun_flag", 1) == 1)
	{
		v[2] = 0;
	}
	
	if(v[2] > log(20)){v[2] = log(20);}
	//if(v[2] < -log(100)){v[2] = -log(100);}

RESULT(v[2])

EQUATION( "no_panic_prop" )
//v[2] = log(10)+(1-V("roth_alpha"))*(log(10)-v[0])+V("roth_alpha")*v[1];
RESULT(log(25))

EQUATION( "Early_2" )

	V("Network_init");
	
	v[0] = 0;
	
	if (V("Early_1") != 1){
		//v[1] = exp(V("panic_prop"))/(exp(V("panic_prop"))+exp(V("no_panic_prop")));
		v[1] = V("run_prob");
	
		if (RND < v[1] + V("epsilon")){
			v[0] = 1;
		}
	}
//v[0] = 0;
RESULT(v[0])

EQUATION("Sum_early")
v[0] = 0; //count variable
CYCLE(cur, "People")
{
	v[0] = v[0] + VS(cur,"Early_2") + VS(cur, "Early_1");
}
RESULT(v[0])

EQUATION("Sum_early_1")
v[0] = 0;
CYCLE(cur, "People")
{
	v[0] = v[0] + VS(cur,"Early_1");
}
RESULT(v[0])

EQUATION("Sum_early_1_rich")
v[0] = 0;
CYCLE(cur, "People")
{
	if (VS(cur, "rich_dummy") == 1)
	{
		v[0] = v[0] + VS(cur,"Early_1");
	}
}
RESULT(v[0])

EQUATION("Sum_early_rich")
v[0] = 0; //count variable
CYCLE(cur, "People")
{
	if(VS(cur, "rich_dummy") == 1)
	{
		v[0] = v[0] + VS(cur,"Early_2");
	}
}
RESULT(v[0])

EQUATION("Sum_early_poor")
v[0] = 0; //count variable
CYCLE(cur, "People")
{
	if(VS(cur, "rich_dummy") == 0)
	{
		v[0] = v[0] + VS(cur,"Early_2");
	}
}
RESULT(v[0])

EQUATION("Sum_early2")
v[0] = 0;
CYCLE(cur, "People")
{
	v[0] = v[0] + VS(cur, "Early_2");
}
RESULT(v[0])

//////////////////
///Bank equations
/////////////////

EQUATION("theta_expected")
v[0] = VL("theta_expected",1);
v[1] = VL("Sum_early", 1)/V("num_of_agents");
v[2] = 0.8*v[0] + 0.2*v[1];
RESULT(v[2])

EQUATION("num_of_agents")
v[0] = 0;
CYCLE(cur, "People")
{
	v[0] = v[0]+1;
}
PARAMETER
RESULT(v[0])

EQUATION("c1_offer") ///assuming CRRA utility function with parameter gamma
//v[0] = (pow(V("R"), 1-1/V("gamma"))/(1-V("theta_expected")))/(1+V("theta_expected")*pow(V("R"), 1-1/V("gamma"))/(1-V("theta_expected")));
v[0] = 1 / (V("theta_expected") + ( 1-V("theta_expected") ) * pow((V("rho") * pow(V("R"), 1-V("gamma"))) , 1/V("gamma")) );

//note that v[0] is the 'first best' offer, the bank makes a safety puffer

if ((1-V("safety_puffer"))*v[0]>1)
{
	v[1] = (1-V("safety_puffer"))*v[0];
}
else
{
	v[1] = 1;
}

RESULT(v[1])

EQUATION("c2_offer") //itt meg ezt az if-ezest at kell gondolni, de szerintem az nem logikus, hogy 1 alatt legyen az offer

v[0] = ((1-V("theta_expected")*V("c1_offer"))*V("R"))/(1-V("theta_expected"));

if ((1-V("safety_puffer"))*v[0]>1)
{
	v[1] = (1-V("safety_puffer"))*v[0];
}
else
{
	v[1] = 1;
}

RESULT(v[1])

EQUATION("num_of_rich")
v[0] = 0;
CYCLE(cur, "People")
{
	if (VS(cur,"rich_dummy")==1)
	{
		v[0] = v[0]+1;
	}
}
PARAMETER
RESULT(v[0])

EQUATION("bank_reserves")  //calcualting the result of the bank

v[0] = 0; //v[0] - poor and early
v[1] = 0; // v[1] - poor and late
v[2] = 0; // v[2] - rich and early
v[3] = 0; // v[3] - rich and late

CYCLE(cur, "People")
{
	if (VS(cur, "rich_dummy") == 0)
	{
		//if (VS("cur", "Early_1") == 0 || VS("cur", "Early_2") == 0)
		if (VS(cur, "Early_1") == 1 || VS(cur, "Early_2") == 1)
		{
			v[0] = v[0] + 1;
		}
		if (VS(cur, "Early_1") == 0 && VS(cur, "Early_2") == 0)
		{
			v[1] = v[1] + 1;
		}
	}
	
	if (VS(cur, "rich_dummy") == 1)
	{
		//if (VS("cur", "Early_1") == 0 || VS("cur", "Early_2") == 0)
		if (VS(cur, "Early_1") == 1 || VS(cur, "Early_2") == 1) 
		{
			v[2] = v[2] + 1;
		}
		if (VS(cur, "Early_1") == 0 && VS(cur, "Early_2") == 0)
		{
			v[3] = v[3] + 1;
		}
	}
}

v[4] = v[0]+v[1]+V("alpha")*(v[2]+v[3]); //sum of money in period 0
v[5] = (v[0]+V("alpha")*v[2])*V("c1_offer");  //sum of money paid to the early consumers
//itt esetleg meg kell nezni hogy csodbe ment-e a bank az elso periodusban?

v[6] = (v[4]-v[5])*V("R");  //liquidity of bank before period 2
v[7] = (v[1]+V("alpha")*v[3])*V("c2_offer");  //total claims in period 2
RESULT(v[6]-v[7])

EQUATION("bankrun_flag")
v[0] = 0;
if (V("bank_reserves") < 0)
{
	v[0] = 1;
}

RESULT(v[0])

EQUATION("num_of_runs");
v[0] = VL("num_of_runs", 1);
if (V("bankrun_flag") == 1)
{
	v[0] = v[0]+1;
}

RESULT(v[0])

EQUATION("run_prob");
v[0] = V("roth_beta");
v[1] = exp( v[0]*V("panic_prop") ) / ( exp(v[0] * V("panic_prop")) + exp(v[0] * V("no_panic_prop")) );
RESULT(   v[1]   )

EQUATION("expected_early")
RESULT(1000*V("theta_expected"))


EQUATION("sum_early1")
v[0] = 0;
CYCLE(cur, "People")
{
	v[0] = v[0] + VS(cur, "Early_1");
}
RESULT(v[0])

EQUATION("sum_early2")
v[0] = 0;
CYCLE(cur, "People")
{
	v[0] = v[0] + VS(cur, "Early_2");
}
RESULT(v[0])

EQUATION("sum_early1_rich")
v[0] = 0;
CYCLE(cur, "People")
{
	v[0] = v[0] + VS(cur, "Early_1")*VS(cur, "rich_dummy");
}
RESULT(v[0])

EQUATION("sum_early1_poor")
v[0] = 0;
CYCLE(cur, "People")
{
	v[0] = v[0] + VS(cur, "Early_1")*(1-VS(cur, "rich_dummy"));
}
RESULT(v[0])

EQUATION("sum_early2_rich")
v[0] = 0;
CYCLE(cur, "People")
{
	v[0] = v[0] + VS(cur, "Early_2")*VS(cur, "rich_dummy");
}
RESULT(v[0])

EQUATION("sum_early2_poor")
v[0] = 0;
CYCLE(cur, "People")
{
	v[0] = v[0] + VS(cur, "Early_2")*(1-VS(cur, "rich_dummy"));
}
RESULT(v[0])

MODELEND

// do not add Equations in this area

void close_sim( void )
{
	// close simulation special commands go here
}


