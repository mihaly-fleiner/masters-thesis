library(eurostat)
library(dplyr)
library(tidyr)

# Download dataset with income by decile group
decile_data <- get_eurostat("ilc_di01", time_format = "num")
df = decile_data[decile_data$indic_il == "TC",]
df = df[df$quantile == "D9",]

# Filter for D1–D10 deciles, EQ_INC (equivalised income), latest year
income_table <- decile_data %>%
  filter(quantile %in% paste0("D", 1:10),
         indic_il == "EQ_INC",
         time == max(TIME_PERIOD)) %>%
  select(geo, quantile, values) %>%
  pivot_wider(names_from = quantile, values_from = values) %>%
  arrange(geo)

# Rename columns
colnames(income_table) <- c("Country", paste0("D", 1:10))

# View or export
print(income_table)
# write.csv(income_table, "EU_income_deciles.csv", row.names = FALSE)




income_table <- decile_data %>%
  filter(quantile %in% paste0("D", 1:9),    # Only D1 to D9
         indic_il == "TC",                 # Total disposable income
         currency == "EUR",                # Euro values only
         TIME_PERIOD == max(TIME_PERIOD)) %>%
  select(quantile, geo, values) %>%
  pivot_wider(names_from = geo, values_from = values) %>%
  arrange(match(quantile, paste0("D", 1:9)))  # Ensure decile order

# Install if not already installed
if (!require(writexl)) install.packages("writexl")
library(writexl)

# Save the income_table to an Excel file
write_xlsx(income_table, "EU_income_deciles_D1_to_D9.xlsx")

