library(readr)
library(dplyr)
library(stringr)
library(purrr)

# === Helper function to read a single .gz file ===
read_res_file <- function(gz_path, sim_name, run_number) {
  lines <- readLines(gzfile(gz_path))
  header_parts <- str_split(lines[1], "\t")[[1]]
  colnames <- str_extract(header_parts, "^[^\\s]+")
  cleaned_lines <- c(paste(colnames, collapse = "\t"), lines[-1])
  data_text <- paste(cleaned_lines, collapse = "\n")
  df <- read_tsv(data_text, show_col_types = FALSE)
  
  # Add simulation name and run number
  df <- df %>%
    mutate(simulation = sim_name,
           run = run_number)
  
  return(df)
}

# Define paths to your simulation folders
path_ineq1 <- "C:/Users/mpfle/LSD/thesis_model_2.0/sim_ineq_rich100"
path_ineq2 <- "C:/Users/mpfle/LSD/thesis_model_2.0/sim_ineq_rich200"

# Read sim_ineq1
df_ineq1 <- map_dfr(1:100, ~ {
  file_path <- file.path(path_ineq1, paste0("sim_ineq_rich100_", .x, ".res.gz"))
  read_res_file(file_path, sim_name = "sim_ineq_rich100", run_number = .x)
})

# Read sim_ineq2
df_ineq2 <- map_dfr(1:100, ~ {
  file_path <- file.path(path_ineq2, paste0("sim_ineq_rich200_", .x, ".res.gz"))
  read_res_file(file_path, sim_name = "sim_ineq_rich200", run_number = .x)
})


###HISTOGRAM OF BANK RUNS

library(ggplot2)
library(dplyr)
library(patchwork)

# Step 1: Summarize the number of bank runs per simulation
summary_ineq1 <- df_ineq1 %>%
  group_by(run) %>%
  summarise(total_runs = max(num_of_runs, na.rm = TRUE))

summary_ineq2 <- df_ineq2 %>%
  group_by(run) %>%
  summarise(total_runs = max(num_of_runs, na.rm = TRUE))


# Calculate means
mean_ineq1 <- mean(summary_ineq1$total_runs, na.rm = TRUE)
mean_ineq2 <- mean(summary_ineq2$total_runs, na.rm = TRUE)

# Step 2: Create histograms
plot_ineq1 <- ggplot(summary_ineq1, aes(x = total_runs)) +
  geom_histogram(binwidth = 1, fill = "#1f77b4", color = "black", alpha = 0.7) +
  geom_vline(xintercept = mean_ineq1, color = "red", linetype = "solid", size = 1) +
  annotate("text", x = mean_ineq1, y = Inf, label = paste0("Mean = ", round(mean_ineq1, 2)),
           vjust = -0.5, hjust = 0.5, color = "red", size = 4) +
  labs(
    title = "Histogram of Bank Runs per Simulation\n(number of rich = 100)",
    x = "Number of Bank Runs",
    y = "Frequency"
  ) +
  theme_minimal(base_size = 10) +
  theme(
    plot.title = element_text(hjust = 0.5)  # Center the title
  )

plot_ineq1
min(summary_ineq1$total_runs)
max(summary_ineq1$total_runs)
mean_ineq1


plot_ineq2 <- ggplot(summary_ineq2, aes(x = total_runs)) +
  geom_histogram(binwidth = 1, fill = "#ff7f0e", color = "black", alpha = 0.7) +
  geom_vline(xintercept = mean_ineq2, color = "red", linetype = "solid", size = 1) +
  annotate("text", x = mean_ineq2, y = Inf, label = paste0("Mean = ", round(mean_ineq2, 2)),
           vjust = -0.5, hjust = 0.5, color = "red", size = 4) +
  labs(
    title = "Histogram of Bank Runs per Simulation\n(number of rich = 200)",
    x = "Number of Bank Runs",
    y = "Frequency"
  ) +
  theme_minimal(base_size = 10) +
  theme(
    plot.title = element_text(hjust = 0.5)  # Center the title
  )

plot_ineq2
min(summary_ineq2$total_runs)
max(summary_ineq2$total_runs)
mean_ineq2


# --- Step 1: Summarise the data ---

# Helper function for summarizing one dataset
summarise_bankrun_stats <- function(df, scenario_name) {
  df %>%
    group_by(bankrun_flag) %>%
    summarise(
      avg_early_total = mean(sum_early1 + sum_early2, na.rm = TRUE),
      avg_early_rich = mean(sum_early1_rich + sum_early2_rich, na.rm = TRUE),
      avg_early_poor = mean(sum_early1_poor + sum_early2_poor, na.rm = TRUE),
      avg_early_rich_1 = mean(sum_early1_rich, na.rm = TRUE),
      avg_early_rich_2 = mean(sum_early2_rich, na.rm = TRUE)
    ) %>%
    mutate(
      frac_rich = avg_early_rich / avg_early_total,
      frac_poor = avg_early_poor / avg_early_total,
      scenario = scenario_name
    )
}

# Summarize for both datasets
summary_ineq1 <- summarise_bankrun_stats(df_ineq1, "ineq1 (100 rich)")
summary_ineq2 <- summarise_bankrun_stats(df_ineq2, "ineq2 (200 rich)")

# Combine
summary_all <- bind_rows(summary_ineq1, summary_ineq2)

# --- Step 2: Print a nice table ---
print(summary_all)
print(summary_all[3:4,c(1, 5:6, 9)])
