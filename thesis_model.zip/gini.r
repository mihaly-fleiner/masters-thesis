# Install and load the package for Gini if needed
if (!require(ineq)) {
  install.packages("ineq")
}
library(ineq)

#0 is perfect equality
# Setting A: 100 rich agents (income 5), 900 poor agents (income 1)
income_A <- c(rep(1, 900), rep(3, 100))
gini_A <- ineq(income_A, type = "Gini")
cat("Gini for Setting A:", gini_A, "\n")

# Setting B: 300 rich agents (income 2.5), 700 poor agents (income 1)
income_B <- c(rep(1, 800), rep(3, 200))
gini_B <- ineq(income_B, type = "Gini")
cat("Gini for Setting B:", gini_B, "\n")



num_of_rich1 = 150
wealth_of_rich1 = 3

num_of_rich2 = 400
wealth_of_rich2 = 2.22

# Setting A: 100 rich agents (income 5), 900 poor agents (income 1)
income_A <- c(rep(1, 1000-num_of_rich1), rep(wealth_of_rich1, num_of_rich1))
gini_A <- ineq(income_A, type = "Gini")
cat("Gini for Setting A:", gini_A, "\n")

# Setting B: 300 rich agents (income 2.5), 700 poor agents (income 1)
income_B <- c(rep(1, 1000-num_of_rich2), rep(wealth_of_rich2, num_of_rich2))
gini_B <- ineq(income_B, type = "Gini")
cat("Gini for Setting B:", gini_B, "\n")



num_of_rich1 = 150
wealth_of_rich1 = 5

num_of_rich2 = 75
wealth_of_rich2 = 8

# Setting A: 100 rich agents (income 5), 900 poor agents (income 1)
income_A <- c(rep(1, 1000-num_of_rich1), rep(wealth_of_rich1, num_of_rich1))
gini_A <- ineq(income_A, type = "Gini")
cat("Gini for Setting A:", gini_A, "\n")

# Setting B: 300 rich agents (income 2.5), 700 poor agents (income 1)
income_B <- c(rep(1, 1000-num_of_rich2), rep(wealth_of_rich2, num_of_rich2))
gini_B <- ineq(income_B, type = "Gini")
cat("Gini for Setting B:", gini_B, "\n")
