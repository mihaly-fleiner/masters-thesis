library(readr)
library(stringr)

# A .gz fájl teljes elérési útja
gz_path <- "C:/Users/mpfle/LSD/thesis_model_2.0/initial_with_heterog_and_netw/initial_with_heterog_and_netw_1.res.gz"

# Beolvasás GZIP fájlból
lines <- readLines(gzfile(gz_path))

# Fejléc feldolgozása: csak az első szót használjuk oszlopnévnek
header_parts <- str_split(lines[1], "\t")[[1]]
colnames <- str_extract(header_parts, "^[^\\s]+")

# Újraépített tartalom tiszta fejléc sorral
cleaned_lines <- c(paste(colnames, collapse = "\t"), lines[-1])
data_text <- paste(cleaned_lines, collapse = "\n")

# Tiszta tibble beolvasása
df <- read_tsv(data_text, show_col_types = FALSE)

# Ellenőrzés
print(head(df))
