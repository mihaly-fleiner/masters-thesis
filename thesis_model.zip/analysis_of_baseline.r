library(readr)
library(dplyr)
library(stringr)
library(purrr)

# === Helper function to read a single .gz file ===

read_res_file <- function(gz_path, sim_name, run_number) {
  lines <- readLines(gzfile(gz_path))
  header_parts <- str_split(lines[1], "\t")[[1]]
  colnames <- str_extract(header_parts, "^[^\\s]+")
  cleaned_lines <- c(paste(colnames, collapse = "\t"), lines[-1])
  data_text <- paste(cleaned_lines, collapse = "\n")
  df <- read_tsv(data_text, show_col_types = FALSE)
  
  # Add source label and run number
  df <- df %>%
    mutate(simulation = sim_name,
           run = run_number)
  
  return(df)
}

path <- "C:/Users/mpfle/LSD/thesis_model_2.0/sim_homogen"
df <- map_dfr(1:100, ~ {
  file_path <- file.path(path, paste0("sim_homogen_", .x, ".res.gz"))
  read_res_file(file_path, sim_name = "sim_homogen", run_number = .x)
})

sum(df$bankrun_flag)
max(df$num_of_runs)

library(ggplot2)

# Step 1: Extract final number of runs for each simulation
final_runs <- df %>%
  group_by(run) %>%
  summarize(total_runs = max(num_of_runs)) %>%
  ungroup()

# Step 2: Plot histogram
ggplot(final_runs, aes(x = total_runs)) +
  geom_histogram(binwidth = 1, fill = "skyblue", color = "black") +
  theme_minimal() +
  labs(
    title = "Histogram of Bank Runs per Simulation",
    x = "Number of Bank Runs",
    y = "Frequency"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5)  # Center the title
  )

# Step 3: Create general summary table
summary_table <- final_runs %>%
  count(total_runs) %>%
  rename(
    number_of_runs = total_runs,
    number_of_simulations = n
  ) %>%
  arrange(number_of_runs)

# Show the table
print(summary_table)



###early1 early2
library(dplyr)
library(ggplot2)

# Step 1: Filter first simulation and first 200 rows
df_first_run_200 <- df %>%
  filter(run == 1) %>%
  slice(1:200) %>%
  mutate(time_step = row_number())  # create a proper time_step column

# Step 2: Better plot
ggplot(df_first_run_200, aes(x = time_step)) +
  geom_line(aes(y = sum_early1, color = "Type 1 early"), size = .2) +
  geom_line(aes(y = sum_early2, color = "Type 2 early"), size = .2) +
  scale_color_manual(
    values = c("Type 1 early" = "#1f77b4", "Type 2 early" = "#ff7f0e")
  ) +
  theme_minimal(base_size = 10) +  
  labs(
    title = "Number of early agents",
    x = "Number of Round",
    y = " ",
    color = "Group"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),
    axis.title = element_text(),
    legend.title = element_text(),
    legend.position = "top",
    panel.grid.minor = element_blank()  # remove minor gridlines
  )


###bank reserves

# Step 1: Prepare data (same as before)
df_first_run_200 <- df %>%
  filter(run == 1) %>%
  slice(1:200) %>%
  mutate(time_step = row_number())

# Step 2: Plot bank_reserves
ggplot(df_first_run_200, aes(x = time_step, y = bank_reserves)) +
  geom_line(color = "#2ca02c", size = .2) +  # green line, slightly thicker
  theme_minimal(base_size = 10) +
  labs(
    title = "Bank Reserves over Time",
    x = "Number of Round",
    y = "Bank Reserves"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),
    axis.title = element_text(),
    legend.position = "none",    # no legend needed, only one variable
    panel.grid.minor = element_blank()
  )




###expexted theta and realized early

# Step 1: Filter for the first simulation (run == 1) and the first 200 time steps
df_first_run_200 <- df %>%
  filter(run == 1) %>%         # Filter for the first simulation
  slice(1:200) %>%             # Take the first 200 time steps
  mutate(time_step = row_number(),   # Create a time_step column
         sum_early1_early2 = sum_early1 + sum_early2) # Create a column for the sum of early1 and early2

# Step 2: Plot expected_theta and sum of early1 and early2 for the first simulation
ggplot(df_first_run_200, aes(x = time_step)) +
  geom_line(aes(y = theta_expected*1000, color = "Expected"), size = .2) + 
  geom_line(aes(y = sum_early1_early2, color = "Realized"), size = .2) +  # Dotted line for the sum
  scale_color_manual(values = c("Expected" = "#1f77b4", "Realized" = "#ff7f0e")) +  # Custom colors
  theme_minimal(base_size = 14) +
  labs(
    title = "Number of Expected and Realized Early Agents",
    x = "Number of Round",
    y = "",
    color = "Variable"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),
    axis.title = element_text(),
    legend.position = "top",
    panel.grid.minor = element_blank()
  )



###c1 offer c2 offer

library(dplyr)
library(ggplot2)

# Step 1: Filter for the first simulation (run == 1) and the first 200 time steps
df_first_run_200 <- df %>%
  filter(run == 1) %>%         # Filter for the first simulation
  slice(1:200) %>%             # Take the first 200 time steps
  mutate(time_step = row_number())   # Create a time_step column

# Step 2: Plot c1_offer and c2_offer for the first simulation
ggplot(df_first_run_200, aes(x = time_step)) +
  geom_line(aes(y = c1_offer, color = "Period 1"), size = .2) + 
  geom_line(aes(y = c2_offer, color = "Period 2"), size = .2) +  # Dotted line for c2_offer
  scale_color_manual(values = c("Period 1" = "#1f77b4", "Period 2" = "#ff7f0e")) +  # Custom colors for c1_offer and c2_offer
  theme_minimal(base_size = 14) +
  labs(
    title = "Offer of the Bank",
    x = "Number of Round",
    y = "",
    color = ""
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),
    axis.title = element_text(size = 10),
    legend.position = "top",
    panel.grid.minor = element_blank()
  )



###analysis of dynamics


# Step 1: Filter data for bankrun_flag == 0 and bankrun_flag == 1
df_bankrun_0 <- df %>% 
  filter(bankrun_flag == 0)

df_bankrun_1 <- df %>% 
  filter(bankrun_flag == 1)

# Step 2: Calculate statistics for bankrun_flag == 0
stats_bankrun_0 <- df_bankrun_0 %>%
  summarise(
    avg_early1 = mean(sum_early1, na.rm = TRUE),
    avg_early2 = mean(sum_early2, na.rm = TRUE),
    sd_early1 = sd(sum_early1, na.rm = TRUE),
    sd_early2 = sd(sum_early2, na.rm = TRUE),
    min_early1 = min(sum_early1, na.rm = TRUE),
    min_early2 = min(sum_early2, na.rm = TRUE),
    max_early1 = max(sum_early1, na.rm = TRUE),
    max_early2 = max(sum_early2, na.rm = TRUE),
    median_early1 = median(sum_early1, na.rm = TRUE),
    median_early2 = median(sum_early2, na.rm = TRUE)
  )

# Step 3: Calculate statistics for bankrun_flag == 1
stats_bankrun_1 <- df_bankrun_1 %>%
  summarise(
    avg_early1 = mean(sum_early1, na.rm = TRUE),
    avg_early2 = mean(sum_early2, na.rm = TRUE),
    sd_early1 = sd(sum_early1, na.rm = TRUE),
    sd_early2 = sd(sum_early2, na.rm = TRUE),
    min_early1 = min(sum_early1, na.rm = TRUE),
    min_early2 = min(sum_early2, na.rm = TRUE),
    max_early1 = max(sum_early1, na.rm = TRUE),
    max_early2 = max(sum_early2, na.rm = TRUE),
    median_early1 = median(sum_early1, na.rm = TRUE),
    median_early2 = median(sum_early2, na.rm = TRUE)
  )

# Step 4: Print the statistics for comparison
print("Statistics for bankrun_flag == 0")
print(stats_bankrun_0)

print("Statistics for bankrun_flag == 1")
print(stats_bankrun_1)


library(dplyr)
library(ggplot2)
library(tidyr)

# Step 1: Prepare the data by filtering and reshaping it for plotting
df_for_plot <- df %>%
  filter(bankrun_flag %in% c(0, 1)) %>%
  select(run, bankrun_flag, sum_early1, sum_early2) %>%
  pivot_longer(cols = c(sum_early1, sum_early2), names_to = "variable", values_to = "value")

library(ggplot2)

# Create a custom labeller
variable_labels <- c(
  sum_early1 = "Type 1 Early",
  sum_early2 = "Type 2 Early"
)

ggplot(df_for_plot, aes(x = factor(bankrun_flag), y = value, fill = factor(bankrun_flag))) +
  geom_boxplot() +
  facet_wrap(~ variable, scales = "free_y", labeller = labeller(variable = variable_labels)) +
  scale_fill_manual(values = c("0" = "#1f77b4", "1" = "#ff7f0e")) +
  labs(
    title = "Comparison of Early Withdrawals by Bank Run Status",
    x = "",
    y = "",
    fill = "Bank Run Status"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),
    axis.title = element_text(),
    legend.position = "top",
    panel.grid.minor = element_blank(),
    strip.text = element_text(face = "bold", size = 12)  # Make facet titles bold and a bit bigger
  )

# Step 3: Density plot for sum_early1 and sum_early2 for both bankrun_flag == 0 and bankrun_flag == 1
ggplot(df_for_plot, aes(x = value, fill = factor(bankrun_flag), color = factor(bankrun_flag))) +
  geom_density(alpha = 0.5) +
  facet_wrap(~ variable, scales = "free") + # Separate density plots for sum_early1 and sum_early2
  scale_fill_manual(values = c("0" = "#1f77b4", "1" = "#ff7f0e")) +  # Custom colors for bankrun_flag
  scale_color_manual(values = c("0" = "#1f77b4", "1" = "#ff7f0e")) + # Same colors for line borders
  labs(
    title = "Density Plots of sum_early1 and sum_early2 for bankrun_flag == 0 and 1",
    x = "Value",
    y = "Density",
    fill = "Bankrun Flag",
    color = "Bankrun Flag"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5, size = 16),
    axis.title = element_text(face = "bold"),
    legend.position = "top",
    panel.grid.minor = element_blank()
  )


library(dplyr)

# t-test for sum_early1 between bankrun_flag == 0 and bankrun_flag == 1
t_test_early1 <- t.test(sum_early1 ~ bankrun_flag, data = df)
print(t_test_early1)

# t-test for sum_early2 between bankrun_flag == 0 and bankrun_flag == 1
t_test_early2 <- t.test(sum_early2 ~ bankrun_flag, data = df)
print(t_test_early2)

# If data is non-normally distributed, consider using Wilcoxon rank-sum test
wilcox_test_early1 <- wilcox.test(sum_early1 ~ bankrun_flag, data = df)
print(wilcox_test_early1)

wilcox_test_early2 <- wilcox.test(sum_early2 ~ bankrun_flag, data = df)
print(wilcox_test_early2)


# ANOVA for sum_early1 based on bankrun_flag
anova_early1 <- aov(sum_early1 ~ factor(bankrun_flag), data = df)
summary(anova_early1)

# ANOVA for sum_early2 based on bankrun_flag
anova_early2 <- aov(sum_early2 ~ factor(bankrun_flag), data = df)
summary(anova_early2)

