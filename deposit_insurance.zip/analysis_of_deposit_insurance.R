library(readr)
library(dplyr)
library(stringr)
library(purrr)

# === Helper function to read a single .gz file ===
read_res_file <- function(gz_path, sim_name, run_number) {
  lines <- readLines(gzfile(gz_path))
  header_parts <- str_split(lines[1], "\t")[[1]]
  colnames <- str_extract(header_parts, "^[^\\s]+")
  cleaned_lines <- c(paste(colnames, collapse = "\t"), lines[-1])
  data_text <- paste(cleaned_lines, collapse = "\n")
  df <- read_tsv(data_text, show_col_types = FALSE)
  
  # Add simulation name and run number
  df <- df %>%
    mutate(simulation = sim_name,
           run = run_number)
  
  return(df)
}

# Define paths to your simulation folders
path_full_insurance <- "C:/Users/mpfle/LSD/thesis_model_deposit_ins/sim_full_insurance"
path_partial_insurance <- "C:/Users/mpfle/LSD/thesis_model_deposit_ins/sim_partial_insurance"

# Read sim_full_insurance
df_full_insurance <- map_dfr(1:100, ~ {
  file_path <- file.path(path_full_insurance, paste0("sim_full_insurance_", .x, ".res.gz"))
  read_res_file(file_path, sim_name = "sim_full_insurance", run_number = .x)
})

# Read sim_partial_insurance
df_partial_insurance <- map_dfr(1:100, ~ {
  file_path <- file.path(path_partial_insurance, paste0("sim_partial_insurance_", .x, ".res.gz"))
  read_res_file(file_path, sim_name = "sim_partial_insurance", run_number = .x)
})


library(dplyr)
library(patchwork)

# Step 1: Summarize the number of bank runs per simulation
summary_full_insurance <- df_full_insurance %>%
  group_by(run) %>%
  summarise(total_runs = max(num_of_runs, na.rm = TRUE))

summary_partial_insurance <- df_partial_insurance %>%
  group_by(run) %>%
  summarise(total_runs = max(num_of_runs, na.rm = TRUE))

mean(summary_full_insurance$total_runs)
mean(summary_partial_insurance$total_runs)

t_test = t.test(summary_full_insurance$total_runs, summary_partial_insurance$total_runs)
t_test

# Step 1: Filter first simulation and first 200 rows
df_first_run_200 <- df_full_insurance %>%
  filter(run == 2) %>%
  slice(1:200) %>%
  mutate(time_step = row_number())  # create a proper time_step column

# Step 2: Better plot
ggplot(df_first_run_200, aes(x = time_step)) +
  geom_line(aes(y = sum_early1, color = "Type 1 early"), size = .2) +
  geom_line(aes(y = sum_early2, color = "Type 2 early"), size = .2) +
  scale_color_manual(
    values = c("Type 1 early" = "#1f77b4", "Type 2 early" = "#ff7f0e")
  ) +
  theme_minimal(base_size = 10) +  
  labs(
    title = "Number of early agents\n(full insurance)",
    x = "Number of Round",
    y = " ",
    color = "Group"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),
    axis.title = element_text(),
    legend.title = element_text(),
    legend.position = "top",
    panel.grid.minor = element_blank()  # remove minor gridlines
  )

# Step 1: Filter first simulation and first 200 rows
df_first_run_200 <- df_partial_insurance %>%
  filter(run == 2) %>%
  slice(1:200) %>%
  mutate(time_step = row_number())  # create a proper time_step column

# Step 2: Better plot
ggplot(df_first_run_200, aes(x = time_step)) +
  geom_line(aes(y = sum_early1, color = "Type 1 early"), size = .2) +
  geom_line(aes(y = sum_early2, color = "Type 2 early"), size = .2) +
  scale_color_manual(
    values = c("Type 1 early" = "#1f77b4", "Type 2 early" = "#ff7f0e")
  ) +
  theme_minimal(base_size = 10) +  
  labs(
    title = "Number of early agents\n(partial insurance)",
    x = "Number of Round",
    y = " ",
    color = "Group"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),
    axis.title = element_text(),
    legend.title = element_text(),
    legend.position = "top",
    panel.grid.minor = element_blank()  # remove minor gridlines
  )





# Calculate means
mean_full_insurance <- mean(summary_full_insurance$total_runs, na.rm = TRUE)
mean_partial_insurance <- mean(summary_partial_insurance$total_runs, na.rm = TRUE)

# Step 2: Create histograms
plot_full_insurance <- ggplot(summary_full_insurance, aes(x = total_runs)) +
  geom_histogram(binwidth = 1, fill = "#1f77b4", color = "black", alpha = 0.7) +
  geom_vline(xintercept = mean_full_insurance, color = "red", linetype = "solid", size = 1) +
  annotate("text", x = mean_full_insurance, y = Inf, label = paste0("Mean = ", round(mean_full_insurance, 2)),
           vjust = -0.5, hjust = 0.5, color = "red", size = 4) +
  labs(
    title = "Histogram of Bank Runs per Simulation\n(full trust in insurance)",
    x = "Number of Bank Runs",
    y = "Frequency"
  ) +
  theme_minimal(base_size = 10) +
  theme(
    plot.title = element_text(hjust = 0.5)  # Center the title
  )

plot_full_insurance
mean_full_insurance


plot_partial_insurance <- ggplot(summary_partial_insurance, aes(x = total_runs)) +
  geom_histogram(binwidth = 1, fill = "#ff7f0e", color = "black", alpha = 0.7) +
  geom_vline(xintercept = mean_partial_insurance, color = "red", linetype = "solid", size = 1) +
  annotate("text", x = mean_partial_insurance, y = Inf, label = paste0("Mean = ", round(mean_partial_insurance, 2)),
           vjust = -0.5, hjust = 0.5, color = "red", size = 4) +
  labs(
    title = "Histogram of Bank Runs per Simulation\n(partial trust in insurance)",
    x = "Number of Bank Runs",
    y = "Frequency"
  ) +
  theme_minimal(base_size = 10) +
  theme(
    plot.title = element_text(hjust = 0.5)  # Center the title
  )

plot_partial_insurance
mean_partial_insurance






# --- Step 1: Summarise the data ---

# Helper function for summarizing one dataset
summarise_bankrun_stats <- function(df, scenario_name) {
  df %>%
    group_by(bankrun_flag) %>%
    summarise(
      avg_early_total = mean(sum_early1 + sum_early2, na.rm = TRUE),
      avg_early_rich = mean(sum_early1_rich + sum_early2_rich, na.rm = TRUE),
      avg_early_poor = mean(sum_early1_poor + sum_early2_poor, na.rm = TRUE),
      avg_early_rich_1 = mean(sum_early1_rich, na.rm = TRUE),
      avg_early_rich_2 = mean(sum_early2_rich, na.rm = TRUE)
    ) %>%
    mutate(
      frac_rich = avg_early_rich / avg_early_total,
      frac_poor = avg_early_poor / avg_early_total,
      scenario = scenario_name
    )
}

# Summarize for both datasets
summary_full_insurance <- summarise_bankrun_stats(df_full_insurance, "full_insurance (3x)")
summary_partial_insurance <- summarise_bankrun_stats(df_partial_insurance, "partial_insurance (5x)")

# Combine
summary_all <- bind_rows(summary_full_insurance, summary_partial_insurance)

# --- Step 2: Print a nice table ---
print(summary_all)
print(summary_all[3:4,c(1, 5:6, 9)])
