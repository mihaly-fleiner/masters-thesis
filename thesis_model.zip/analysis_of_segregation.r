library(readr)
library(dplyr)
library(stringr)
library(purrr)

# === Helper function to read a single .gz file ===
read_res_file <- function(gz_path, sim_name, run_number) {
  lines <- readLines(gzfile(gz_path))
  header_parts <- str_split(lines[1], "\t")[[1]]
  colnames <- str_extract(header_parts, "^[^\\s]+")
  cleaned_lines <- c(paste(colnames, collapse = "\t"), lines[-1])
  data_text <- paste(cleaned_lines, collapse = "\n")
  df <- read_tsv(data_text, show_col_types = FALSE)
  
  # Add simulation name and run number
  df <- df %>%
    mutate(simulation = sim_name,
           run = run_number)
  
  return(df)
}

# Define paths to your simulation folders
path_seg1 <- "C:/Users/mpfle/LSD/thesis_model_2.0/sim_seg_0.2_5"
path_seg2 <- "C:/Users/mpfle/LSD/thesis_model_2.0/sim_seg_0.8"

# Read sim_seg1
df_seg1 <- map_dfr(1:100, ~ {
  file_path <- file.path(path_seg1, paste0("sim_seg_0.2_5_", .x, ".res.gz"))
  read_res_file(file_path, sim_name = "sim_seg_0.5", run_number = .x)
})

# Read sim_seg2
df_seg2 <- map_dfr(1:100, ~ {
  file_path <- file.path(path_seg2, paste0("sim_seg_0.8_", .x, ".res.gz"))
  read_res_file(file_path, sim_name = "sim_seg_0.8", run_number = .x)
})


# Step 1: Summarize the number of bank runs per simulation
summary_seg1 <- df_seg1 %>%
  group_by(run) %>%
  summarise(total_runs = max(num_of_runs, na.rm = TRUE))

summary_seg2 <- df_seg2 %>%
  group_by(run) %>%
  summarise(total_runs = max(num_of_runs, na.rm = TRUE))


# Calculate means
mean_seg1 <- mean(summary_seg1$total_runs, na.rm = TRUE)
mean_seg2 <- mean(summary_seg2$total_runs, na.rm = TRUE)


# Step 2: Create histograms
plot_seg1 <- ggplot(summary_seg1, aes(x = total_runs)) +
  geom_histogram(binwidth = 1, fill = "#1f77b4", color = "black", alpha = 0.7) +
  geom_vline(xintercept = mean_seg1, color = "red", linetype = "solid", size = 1) +
  annotate("text", x = mean_seg1, y = Inf, label = paste0("Mean = ", round(mean_seg1, 2)),
           vjust = -0.5, hjust = 0.5, color = "red", size = 4) +
  labs(
    title = "Histogram of Bank Runs per Simulation\n(number of rich = 100)",
    x = "Number of Bank Runs",
    y = "Frequency"
  ) +
  theme_minimal(base_size = 10) +
  theme(
    plot.title = element_text(hjust = 0.5)  # Center the title
  )

plot_seg1
min(summary_seg1$total_runs)
max(summary_seg1$total_runs)
mean_seg1


plot_seg2 <- ggplot(summary_seg2, aes(x = total_runs)) +
  geom_histogram(binwidth = 1, fill = "#ff7f0e", color = "black", alpha = 0.7) +
  geom_vline(xintercept = mean_seg2, color = "red", linetype = "solid", size = 1) +
  annotate("text", x = mean_seg2, y = Inf, label = paste0("Mean = ", round(mean_seg2, 2)),
           vjust = -0.5, hjust = 0.5, color = "red", size = 4) +
  labs(
    title = "Histogram of Bank Runs per Simulation\n(number of rich = 200)",
    x = "Number of Bank Runs",
    y = "Frequency"
  ) +
  theme_minimal(base_size = 10) +
  theme(
    plot.title = element_text(hjust = 0.5)  # Center the title
  )

plot_seg2
min(summary_seg2$total_runs)
max(summary_seg2$total_runs)
mean_seg2

### statistical test

t_test_result <- t.test(summary_seg1$total_runs, summary_seg2$total_runs)
print(t_test_result)
