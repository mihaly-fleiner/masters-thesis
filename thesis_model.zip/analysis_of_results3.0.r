library(readr)
library(dplyr)
library(stringr)
library(purrr)

# === Helper function to read a single .gz file ===
read_res_file <- function(gz_path, sim_name, run_number) {
  lines <- readLines(gzfile(gz_path))
  header_parts <- str_split(lines[1], "\t")[[1]]
  colnames <- str_extract(header_parts, "^[^\\s]+")
  cleaned_lines <- c(paste(colnames, collapse = "\t"), lines[-1])
  data_text <- paste(cleaned_lines, collapse = "\n")
  df <- read_tsv(data_text, show_col_types = FALSE)
  
  # Add source label and run number
  df <- df %>%
    mutate(simulation = sim_name,
           run = run_number)
  
  return(df)
}


# === Read first set: initial_with_heterog_and_netw ===

"""
path1 <- "C:/Users/mpfle/LSD/thesis_model_2.0/initial_with_heterog_and_netw"
df_initial <- map_dfr(1:100, ~ {
  file_path <- file.path(path1, paste0("initial_with_heterog_and_netw_", .x, ".res.gz"))
  read_res_file(file_path, sim_name = "initial", run_number = .x)
})"""

path1 <- "C:/Users/mpfle/LSD/thesis_model_2.0/initial_with_heterog_and_netw"
df_sim1 <- map_dfr(1:100, ~ {
  file_path <- file.path(path1, paste0("initial_with_heterog_and_netw_", .x, ".res.gz"))
  read_res_file(file_path, sim_name = "initial", run_number = .x)
})

# === Read second set: Sim1 ===
path2 <- "C:/Users/mpfle/LSD/thesis_model_2.0/Sim1"
df_sim2 <- map_dfr(1:100, ~ {
  file_path <- file.path(path2, paste0("Sim1_", .x, ".res.gz"))
  read_res_file(file_path, sim_name = "Sim1", run_number = .x)
})


df_all_combined <- bind_rows(df_sim1, df_sim2)

df_all_combined %>%
  group_by(simulation, bankrun_flag) %>%
  summarise(mean_sum_early2 = mean(sum_early2, na.rm = TRUE),
            mean_sum_early_rich = mean(sum_early1_rich + sum_early2_rich, na.rm = TRUE),
            .groups = "drop")

ggplot(df_all_combined, aes(x = simulation, y = sum_early2, fill = factor(bankrun_flag))) +
  geom_boxplot() +
  facet_wrap(~ bankrun_flag) +
  labs(title = "Comparison of sum_early2 by Simulation and Bank Run",
       y = "sum_early2", x = "Simulation")

sum(df_all_combined$bankrun_flag == 1 & df_all_combined$simulation == "initial")
sum(df_all_combined$bankrun_flag == 1 & df_all_combined$simulation == "Sim1")

