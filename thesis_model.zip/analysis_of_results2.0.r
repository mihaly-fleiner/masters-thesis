read_res_gz <- function(file_path) {
  lines <- readLines(gzfile(file_path))
  header_parts <- str_split(lines[1], "\t")[[1]]
  colnames <- str_extract(header_parts, "^[^\\s]+")
  cleaned_lines <- c(paste(colnames, collapse = "\t"), lines[-1])
  data_text <- paste(cleaned_lines, collapse = "\n")
  read_tsv(data_text, show_col_types = FALSE)
}

base_path <- "C:/Users/mpfle/LSD/thesis_model_2.0/initial_with_heterog_and_netw"
file_names <- paste0("initial_with_heterog_and_netw_", 1:100, ".res.gz")
file_paths <- file.path(base_path, file_names)

res_list <- setNames(lapply(file_paths, read_res_gz), paste0("run_", 1:100))

library(dplyr)
library(purrr)

df_all <- map2_dfr(res_list, names(res_list), ~mutate(.x, run = .y))
df_all <- df_all %>% select(-`NA`)



###ANALYSIS



#ANALYSIS 1.0 - Check whether sum_early2 is higher in case of a run
library(ggplot2)

ggplot(df_all, aes(x = factor(bankrun_flag), y = sum_early2)) +
  geom_boxplot() +
  labs(title = "Distribution of sum_early2 by Bank Run Status",
       x = "Bank Run Flag (0 = No, 1 = Yes)",
       y = "sum_early2") +
  theme_minimal()

df_all %>%
  group_by(bankrun_flag) %>%
  summarise(mean_sum_early2 = mean(sum_early2, na.rm = TRUE),
            sd_sum_early2 = sd(sum_early2, na.rm = TRUE))

t_test_result <- t.test(sum_early2 ~ bankrun_flag, data = df_all)
print(t_test_result)


###ANALYSIS 2.0 - Check whether there are more early rich in case of a run

df_all <- df_all %>%
  mutate(sum_early_rich = sum_early1_rich + sum_early2_rich)

ggplot(df_all, aes(x = factor(bankrun_flag), y = sum_early_rich)) +
  geom_boxplot() +
  labs(title = "Distribution of sum_early_rich by Bank Run Status",
       x = "Bank Run Flag (0 = No, 1 = Yes)",
       y = "sum_early_rich") +
  theme_minimal()

df_all %>%
  group_by(bankrun_flag) %>%
  summarise(mean_sum_early_rich = mean(sum_early_rich, na.rm = TRUE),
            sd_sum_early_rich = sd(sum_early_rich, na.rm = TRUE))

t_test_rich <- t.test(sum_early_rich ~ bankrun_flag, data = df_all)
print(t_test_rich)

